﻿namespace MsWebGame.Portal.Database.DTO
{
    public class EffectJackpot
    {
        public string NickName { get; set; }
        public long JackpotValue { get; set; }
        public int BetValue { get; set; }
        public string GameName { get; set; }
        public int ServiceID { get; set; }
    }
}