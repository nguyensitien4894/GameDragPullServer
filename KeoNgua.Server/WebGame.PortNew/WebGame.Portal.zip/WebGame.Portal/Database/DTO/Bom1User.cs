﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MsWebGame.Portal.Database.DTO
{
    public class Bom1User
    {
        public long UserID { get; set; }
        public string UserDisplayName { get; set; }
        public int DegreeID { get; set; }
        public int B1P { get; set; }
       


    }
}