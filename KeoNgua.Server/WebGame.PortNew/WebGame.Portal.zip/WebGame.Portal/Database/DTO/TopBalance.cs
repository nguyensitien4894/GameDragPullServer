﻿namespace MsWebGame.Portal.Database.DTO
{
    public class TopBalance
    {
        public string GameAccountName { get; set; }
        public long Balance { get; set; }
        public int ServiceID { get; set; }
    }
}