﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MsWebGame.Portal.Helpers.OTPs.OtpAps
{
    public class OtpAppResponse
    {
        public int ResponseCode { get; set; }
        public string Message { get; set; }
    }
}