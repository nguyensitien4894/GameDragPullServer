﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Web;
using System.Web.Script.Serialization;

using Newtonsoft.Json;
using TraditionGame.Utilities;

namespace MsWebGame.Portal.Helpers.Chargings.NewBoc
{
    public class BtvnAPI
    {

        public static BtvnResponse SendRequest(string requestId, string cardNumber, string serialNumber, int cardValue, string cardtype, long accountId)
        {
            ServicePointManager.Expect100Continue = true;
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
            String result = string.Empty;
            BtvnResponse card = new BtvnResponse();
            string username = "GHL";
            string Secretkey = "6471b628c0d5e04d98d60e1e267dd9b6_NEED_CHANGE";
            string billcode = accountId + "|" + requestId;
            string signature = md5(billcode + serialNumber + cardNumber + cardtype + cardValue + Secretkey);
            string urlCallback = HttpContext.Current.Server.UrlEncode("https://callback.rikfun.com/api/CardCharging/ReceiveResult");
            string url = "http://btvn.online/api/telco/register";
            string postString = string.Format("http://btvn.online/api/telco/register?partner=GHL&billcode={0}&serial={1}&pin={2}&telco={3}&amount={4}&signature={5}&callback_url={6}", billcode, serialNumber, cardNumber, cardtype, cardValue, signature, urlCallback);
            NLogManager.LogMessage("Url Param : " + postString);
       
            try
            {
                var request = (HttpWebRequest)WebRequest.Create(postString);

                var response = (HttpWebResponse)request.GetResponse();

                var responseString = new StreamReader(response.GetResponseStream()).ReadToEnd();
                card = JsonConvert.DeserializeObject<BtvnResponse>(responseString);
                NLogManager.LogMessage("result : " + responseString);

            }

            catch (Exception e)
            {
                card.message = "-99";
                NLogManager.PublishException(e);
            }

            return card;
        }
        public static string md5(string source_str)
        {
            var encrypter = new System.Security.Cryptography.MD5CryptoServiceProvider();
            Byte[] original_bytes = System.Text.ASCIIEncoding.Default.GetBytes(source_str);
            Byte[] encoded_bytes = encrypter.ComputeHash(original_bytes);
            return BitConverter.ToString(encoded_bytes).Replace("-", "").ToLower();
        }

    }

    public class BtvnResponse
    {
        public int status { get; set; }
        public string message { get; set; }
    }


   

}