﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MsWebGame.Portal.Models.Momo
{
    public class MomoInfoObject
    {
        public string MomoPhoneNumber { get; set; }
        public string MomoUserName { get; set; }
        public long MomoBalance { get; set; }
    }

}