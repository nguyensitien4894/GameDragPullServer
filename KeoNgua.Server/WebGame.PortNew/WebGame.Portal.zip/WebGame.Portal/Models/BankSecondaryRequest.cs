﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MsWebGame.Portal.Models
{
    public class BankSecondaryRequest
    {
        public long Amount { get; set; }
        public int OperatorID { get; set; }
    }
}