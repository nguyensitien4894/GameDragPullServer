﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MsWebGame.Portal.Models
{
    public class SmsCardModel
    {
        public int Value { get; set; }
        public string Systax { get; set; }
        public long Amount { get; set; }
      
    }
}