﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MsWebGame.Portal.Models
{
    public class NextVP
    {
        public int RankID { get; set; }
        public string RankName { get; set; }
        public long VP { get; set; }
    }
}