﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MsWebGame.Portal.Models.OTPs
{
    public class OtpType
    {
        public int ID { get; set; }
        public string Name { get; set; }
    }
}