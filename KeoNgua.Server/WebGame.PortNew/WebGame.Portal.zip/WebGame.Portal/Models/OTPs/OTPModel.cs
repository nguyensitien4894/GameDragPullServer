﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MsWebGame.Portal.Models.OTPs
{
    public class OTPModel
    {
        public int status { get; set; }
        public string sms { get; set; }
        public string type { get; set; }
       
    }
}