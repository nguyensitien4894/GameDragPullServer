﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

using TraditionGame.Utilities.Messages;
using TraditionGame.Utilities.Session;
using TraditionGame.Utilities.Utils;
using WebGame.Payment.Database.DAO;
using MsWebGame.Portal.Database.DAO;
using MsWebGame.Portal.Database.DTO;
using MsWebGame.Portal.Helpers;
using TraditionGame.Utilities;
using TraditionGame.Utilities.Api;
using TraditionGame.Utilities.Constants;

namespace MsWebGame.Portal.Controllers
{
    [RoutePrefix("api/UserTranfer")]
    public class UserTranferController : BaseApiController
    {
        private static readonly string _ChangeBalanceUrl = System.Configuration.ConfigurationManager.AppSettings["CHANGE_BALANCE_URL"].ToString();
        private static readonly string _ApiChangeBalance = System.Configuration.ConfigurationManager.AppSettings["API_CHANGE_BALANCE"].ToString();
        [ActionName("TranferBit")]
        [HttpPost]
        public dynamic TranferBit([FromBody] dynamic input)
        {
            try
            {
                string APPROVE = ConfigurationManager.AppSettings["UserTranfer_APPROVED"].ToString();
               if (APPROVE != "1")
                {
                    return AnphaHelper.Close();
                }

                long accountId = AccountSession.AccountID;
                //kiểm tra authen 
                var displayName = AccountSession.AccountName;
                if (accountId <= 0 || String.IsNullOrEmpty(displayName))
                {
                    return new
                    {
                        ResponseCode = Constants.UNAUTHORIZED,
                        Message = ErrorMsg.UnAuthorized
                    };
                }

                var account = AccountDAO.Instance.GetProfile(accountId, ServiceID);
                if (account == null)
                {
                    return new
                    {
                        ResponseCode = Constants.UNAUTHORIZED,
                        Message = ErrorMsg.UnAuthorized
                    };
                }
                if (account.Status != 1)
                {
                    return new
                    {
                        ResponseCode = -1005,
                        Message = ErrorMsg.AccountLock
                    };
                }

                //kiểm tra tham số
                string Amount = input.Amount ?? string.Empty;
                string Otp = input.Otp ?? string.Empty;
                string note = input.Note ?? string.Empty;
                string NickName = input.NickName ?? string.Empty;
               
               
                //kiểm tra user name
                if ((String.IsNullOrEmpty(NickName)))
                {

                    return new
                    {
                        ResponseCode = -1005,
                        Message = ErrorMsg.UserNameTranferInvalid
                    };
                }
                //kiểm tra amount
                if ((String.IsNullOrEmpty(Amount)))
                {

                    return new
                    {
                        ResponseCode = -1005,
                        Message = ErrorMsg.AmountInValid
                    };
                }
                var lngAmount = ConvertUtil.ToLong(Amount);
                if (lngAmount < 10000)
                {
                    return new
                    {
                        ResponseCode = -1005,
                        Message = String.Format(ErrorMsg.MinAmountTranfer, "10.000"),
                    };
                }
               
                //note nếu có thì lỗi
                if (!String.IsNullOrEmpty(note) && note.Length > 50)
                {
                    return new
                    {
                        ResponseCode = -1005,
                        Message = ErrorMsg.NoteLengthOverMax
                    };
                }
                // kiểm tra otp
                if (String.IsNullOrEmpty(Otp))
                {
                    return new
                    {
                        ResponseCode = -1005,
                        Message = ErrorMsg.OtpEmpty
                    };
                }
                NickName = NickName.Trim();

                //logic user name 
                var userReceive = new UserAgency();
                userReceive.IsBot = false;
                int isBalackList = 0;
                AccountDAO.Instance.UserCheckBlackList(accountId,out isBalackList);
                if (isBalackList!=1){
                    userReceive = UserDAO.Instance.GetUserByNickName(NickName,ServiceID);
                    if (userReceive == null)
                    {
                        userReceive = UserDAO.Instance.GetBotByNickName(NickName);
                        if (userReceive == null)
                        {
                            return new
                            {
                                ResponseCode = -1005,
                                Message = ErrorMsg.AccountReceiveNotExist
                            };
                        }
                        userReceive.IsBot = true;


                    }
                }else
                {
                    //giữ lại số tiền nghi ngờ đại lý
                    string DAILY = ConfigurationManager.AppSettings["NPH_DL"].ToString();
                    userReceive = UserDAO.Instance.GetUserByNickName(DAILY, ServiceID);
                    note = String.Format("{0}-NPH tạm thời giữ tiền do phát sinh giao dịch nghi ngờ", note);
                }
                

                if (accountId == userReceive.AccountID)
                {
                    return new
                    {
                        ResponseCode = -1005,
                        Message = ErrorMsg.UserTranferEqualUser
                    };
                }

                //check limit tranfer
                int outUpdatePhone;
                AccountDAO.Instance.UserCheckUpdatePhone(accountId, out outUpdatePhone);
                if (outUpdatePhone != 1)
                {
                    return new
                    {
                        ResponseCode = -232,
                        Message = ErrorMsg.ERR_UPDATE_PHONE_LESS_24
                    };
                }


                //logic amount 

                double fee = 0;
                //lấy phí của đại lý
                long agencyId = 0;
                short agencyLevel = 0;
                if (userReceive.AccountType == 2)//đại lý
                {
                   
                   
                    agencyId = userReceive.AccountID;
                    agencyLevel = (short)userReceive.AccountLevel;

                    string strFee;
                    if (agencyLevel == 2)
                    {
                        ParaConfigDAO.Instance.GetConfigValue("TRANSFEE", "USER_TO_AGENCY_LEVEL2", out strFee);
                    }
                    else
                    {
                        ParaConfigDAO.Instance.GetConfigValue("TRANSFEE", "USER_TO_AGENCY_LEVEL1", out strFee);
                    }

                    fee = Convert.ToDouble(strFee);
                }
                else
                {
                    //user thường
                    string strFee;
                    ParaConfigDAO.Instance.GetCoreConfig("TRANSFEE", "TRANSFEE", out strFee);
                    fee = Convert.ToDouble(strFee);

                }
                //chưa cấu hình phí giao dịch
                if (fee < 0)
                {
                    return new
                    {
                        ResponseCode = -1005,
                        Message = ErrorMsg.FeeNotConfig
                    };
                }
                //kiểm tra có đủ phí để chuyển Bit hay không
                var balance = account.Balance;
                long lostAmount = lngAmount + (long)Math.Round(lngAmount * fee);
                if (balance < lostAmount)
                {
                    return new
                    {
                        ResponseCode = -1005,
                        Message = ErrorMsg.AmountNotValidToTranferBit
                    };
                }
                //logic otp
                int resOtp = 0;
                long otpID;
                string otmsg;
                SMSDAO.Instance.ValidOtp(account.AccountID, account.PhoneNumber, Otp, ServiceID, out resOtp, out otpID, out otmsg);
                if (resOtp != 1)
                {
                    return new
                    {
                        ResponseCode = -5,
                        Message = Otp.Trim().Length == 6 ? otmsg : ErrorMsg.OtpIncorrect
                    };
                }
                NLogManager.LogMessage(String.Format("StartTranfer: from {0} to {1} at {2} type {3}", account.AccountName,userReceive.NickName,DateTime.Now,userReceive.AccountType));
                if (userReceive.AccountType != 2)//người dùng thường
                {
                  //  string note = string.Format("{0} chuyển {1} Q cho {2} vào ngày {3}", account.AccountName, lostAmount.LongToMoneyFormat(), userReceive.UserName, DateTime.UtcNow);
                    long TransID = 0;
                    long Wallet = 0;
                    int Response = 0;
                    NLogManager.LogMessage(String.Format("Add money to user :  {0} amount {1} at {2}", userReceive.NickName,lngAmount, DateTime.Now));
                    if (userReceive.IsBot)
                    {
                        UserTranferDAO.Instance.UserTransferToBot(accountId, userReceive.AccountID, lngAmount, ServiceID, note, out TransID, out Wallet, out Response);
                    }
                    else
                    {
                        UserTranferDAO.Instance.UserTransferToUser(accountId, userReceive.AccountID, lngAmount, note, ServiceID, out TransID, out Wallet, out Response);
                    }
                    
                    NLogManager.LogMessage(String.Format(" EndTranfer :  {0} amount {1} at  Response {2} ", userReceive.NickName, lngAmount,Response));
                    if (Response == 1)
                    {
                        return new
                        {
                            ResponseCode = 1,
                            Balance=Wallet,
                            Message = ErrorMsg.TranferBitSuccess
                        };
                    }
                    else if (Response == -10)
                    {
                        return new
                        {
                            ResponseCode = -1005,
                            Message = ErrorMsg.ParamaterInvalid
                        };
                    }
                    else if (Response == -105)
                    {
                        return new
                        {
                            ResponseCode = -1005,
                            Message = ErrorMsg.AccountReceiveNotExist
                        };
                    }
                    else if (Response == -507)
                    {
                        return new
                        {
                            ResponseCode = -1005,
                            Message = ErrorMsg.InProccessException
                        };
                    }
                    else if (Response == -504)
                    {
                        return new
                        {
                            ResponseCode = -1005,
                            Message = ErrorMsg.AmountNotValidToTranferBit
                        };
                    }
                    else if(Response == -501)
                    {
                        return new
                        {
                            ResponseCode = -1005,
                            Message = String.Format(ErrorMsg.MinAmountTranfer,(10000).IntToMoneyFormat())
                        };
                    }
                    else
                    {
                        return new
                        {
                            ResponseCode = -99,
                            Message = ErrorMsg.InProccessException
                        };
                    }

                }
                else
                {
                    //nghiệp vụ chuyển tiền cho đại lý 
                    int limitResponse = 0;
                    UserTranferDAO.Instance.UserCheckLimit(accountId, lngAmount, out limitResponse);
                    if (limitResponse != 1)
                    {
                        if (limitResponse == -202 || limitResponse == -223)
                        {
                            return new
                            {
                                ResponseCode = -1005,
                                Message = ErrorMsg.AccountLock
                            };
                        }
                        else if (limitResponse == -227)
                        {
                            return new
                            {
                                ResponseCode = -1005,
                                Message = ErrorMsg.TranferOverMoney
                            };
                        }
                        else
                        {
                            return new
                            {
                                ResponseCode = -1005,
                                Message = ErrorMsg.InProccessException
                            };
                        }
                    }
                  
                    long RemainWallet = 0;
                    int Response = 0;
                    long TransID = 0;
                    long OrgTransID = 0;
                    NLogManager.LogMessage(String.Format(" UserTransferToAgencyAdmin:  {0} amount {1} at {2}", userReceive.NickName, lngAmount, DateTime.Now));
                    UserTranferDAO.Instance.UserTransferToAgencyAdmin(accountId, agencyId, userReceive.NickName, 2, agencyLevel, lngAmount, note,ServiceID, out OrgTransID, out RemainWallet, out Response);
                    NLogManager.LogMessage(String.Format(" End UserTransferToAgencyAdmin :  {0} amount {1} at  Response {2} ", userReceive.NickName, lngAmount, Response));
                    if (Response == 1)
                    {
                        Response = 0;
                     
                        NLogManager.LogMessage(String.Format(" StartUserTransfer:  {0} amount {1} at {2}", userReceive.NickName, lngAmount, DateTime.Now));
                       // UserTranferDAO.Instance.UserTransfer(accountId, agencyId, 2, lngAmount, note, OrgTransID, out TransID, out RemainWalletAgency, out Response);
                        NLogManager.LogMessage(String.Format(" End UserTransfer :  {0} amount {1} at  Response {2} ", userReceive.NickName, lngAmount, Response));
                        //send telegram id
                        try
                        {
                            if (userReceive.TelegramID.HasValue && userReceive.TelegramID.Value > 0)
                            {

                                var strNotifty = String.Format("Bạn vừa nhận {0} Q từ nickname {1}", lngAmount.LongToMoneyFormat(), account.AccountName);
                                GunNotifyChangeBalance(userReceive.TelegramID.Value, strNotifty);
                            }
                        }catch(Exception ex)
                        {

                        }
                       
                            return new
                            {
                                ResponseCode = 1,
                                Balance = RemainWallet,
                                Message = ErrorMsg.TranferBitSuccess
                            };
                       
                       
                    }
                    else
                    {
                        if (Response == -10)
                        {
                            return new
                            {
                                ResponseCode = -1005,
                                Message = ErrorMsg.ParamaterInvalid
                            };
                        }
                        else if (Response == -105)
                        {
                            return new
                            {
                                ResponseCode = -1005,
                                Message = ErrorMsg.AccountReceiveNotExist
                            };
                        }
                        else if (Response == -507)
                        {
                            return new
                            {
                                ResponseCode = -1005,
                                Message = ErrorMsg.InProccessException
                            };
                        }
                        else if (Response == -504)
                        {
                            return new
                            {
                                ResponseCode = -1005,
                                Message = ErrorMsg.AmountNotValidToTranferBit
                            };
                        }
                        else
                        {
                            return new
                            {
                                ResponseCode = -99,
                                Message = ErrorMsg.InProccessException
                            };
                        }

                    }

                    //kết thúc nghiệp vụ chuyển tiề cho đại lý 


                }
             

            }
            catch (Exception ex)
            {
                NLogManager.PublishException(ex);
                return new
                {
                    ResponseCode = -99,
                    Description = ErrorMsg.InProccessException
                };
            }
        }

        [ActionName("GetHistory")]
        [HttpGet]
        public dynamic GetHistory(int type)
        {
            long accountId = AccountSession.AccountID;

            var displayName = AccountSession.AccountName;
            if (accountId <= 0 || String.IsNullOrEmpty(displayName))
            {
                return new
                {
                    ResponseCode = Constants.UNAUTHORIZED,
                    Message = ErrorMsg.UnAuthorized
                };
            }

            try
            {
                int totalRecord;
                var list = UserTranferDAO.Instance.BalanceLogsList(accountId,null, type, null,null,ServiceID,1,100, out totalRecord);
                var result = new List<BalanceLogs>();
                if (list != null && list.Any())
                {
                    foreach(var item in list)
                    {
                        item.Description = item.Description.CusSubString(20);
                        result.Add(item);
                    }
                    
                }
                return new
                {
                    ResponseCode = 1,
                    List = result
                };
            }
            catch (Exception ex)
            {
                NLogManager.PublishException(ex);
                return new
                {
                    ResponseCode = -99,
                    List = new List<BalanceLogs>()
                };
            }
        }

       
        private void GunNotifyChangeBalance(long tele_id, string content)
        {
            try
            {
                //var api = new ApiUtil<dynamic>();
                //api.ApiAddress = _ChangeBalanceUrl;
                //api.URI = _ApiChangeBalance;
                //var result = api.Send(new { ChatID = tele_id, Content = content });
                TeleNotify(tele_id.ToString(), content);
                //NLogManager.LogMessage(string.Format("GunNotifyChangeBalance-Res:{0}", result.ResponseCode));
            }
            catch (Exception ex)
            {
                NLogManager.PublishException(ex);
            }
        }

    }
}
