﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;
using TraditionGame.Utilities.IpAddress;
using TraditionGame.Utilities.Messages;
using TraditionGame.Utilities.Utils;
using WebGame.Header.Utils._1Pays.SMSs;
using WebGame.Payment.Database.DAO;
using MsWebGame.Portal.Database.DAO;
using MsWebGame.Portal.Helpers.OTPs.MobileSMS;
using TraditionGame.Utilities;
using System.IO;
using System.Text;

namespace MsWebGame.Portal.Controllers
{
    public class BaseApiController : ApiController
    {
        protected HttpContext _Context;
        public BaseApiController()
        {

        }
        protected bool IsVieNamMobilePhone(string phoneNumber)
        {
            var listPhone = new List<string>() { "092", "056", "058", "0186", "0188" };
            var splitPhone = phoneNumber.Substring(0, 3);
            return listPhone.Contains(splitPhone);


        }
        protected  dynamic TeleNotify(string chatID,string content)
        {
            try
            {
                string apiToken = ConfigurationManager.AppSettings["TOKEN_NOTIFY_TELE"].ToString();
                string urlString = "https://api.telegram.org/bot{0}/sendMessage?chat_id={1}&text={2}";


                urlString = String.Format(urlString, apiToken, chatID, content);
                WebRequest request = WebRequest.Create(urlString);
                Stream rs = request.GetResponse().GetResponseStream();
                StreamReader reader = new StreamReader(rs);
                string line = "";
                StringBuilder sb = new StringBuilder();
                while (line != null)
                {
                    line = reader.ReadLine();
                    if (line != null)
                        sb.Append(line);
                }
                string response = sb.ToString();
                return new
                {
                    ResponseCode = 1,

                };
            }catch(Exception ex)
            {
                NLogManager.PublishException(ex);
                return new
                {
                    ResponseCode = 0,

                };
            }

            
        }
        protected int  USER_TYPE=1;
        protected int  AGENCY_TYPE = 2;
        protected int ServiceID = ConvertUtil.ToInt(ConfigurationManager.AppSettings["SERVICE_ID"].ToString());
        /// <summary>
        /// Generate Otp
        /// </summary>
        /// <param name="accountId"></param>
        /// <param name="phone"></param>
        /// <returns></returns>
        protected dynamic GenerateOtpWithTeleSafe(long accountId, string phone,string type)
        {
            if (type == "10")
            {
                var otp = SMSRequest.GenrateOTP(8);
                int response = 0;
                SMSDAO.Instance.SPSmsOTPVerify(ServiceID, accountId, "10", otp, phone, 1, out response);
                if (response == 1)
                {
                    return new
                    {
                        ResponseCode = 1,

                    };
                }
                else if(response==-234)
                {
                    return new
                    {
                        ResponseCode = -1005,
                        Message = ErrorMsg.AccountNotLinkSafe
                    };
                }
                else
                {
                    return new
                    {
                        ResponseCode = -1005,
                        Message = ErrorMsg.MSNErr
                    };
                }
            }
            else
            {
                var otp = SMSRequest.GenrateOTP(7);

                //trừ tiền mã otp
                long responseCurrentID = -99;
                long balance = 0;
                long currentbalance = 0;
                int OtpFeePerTime = 0;
                SMSDAO.Instance.OTPInit(accountId, type, otp, phone.PhoneFormat(), ServiceID, out balance, out currentbalance, out responseCurrentID, out OtpFeePerTime);

                if (responseCurrentID == -2)
                {
                    return new
                    {
                        ResponseCode = -99,
                        Message = ErrorMsg.OTPBitNotEngough
                    };
                }
                else if (responseCurrentID <= 0 && responseCurrentID != -2)
                {

                    return new
                    {
                        ResponseCode = -99,
                        Message = ErrorMsg.OtpBusy
                    };
                }

                var strOtpFormat = ConfigurationManager.AppSettings["OTP_MSG"].ToString();
                var sms = String.Format(strOtpFormat, otp);
                //  var sendResult = test.sendSms(username, pass, brand, sms, newPhone, 1);

                var res = OtpSend.Send(phone, sms);


                int response = 0;
                if (res.code == OtpSuccess.SUCESS)
                {
                    balance = 0;
                    currentbalance = 0;
                    OtpFeePerTime = 0;

                    SMSDAO.Instance.UpdateStatus(responseCurrentID, 1, 1, DateTime.Now.ToShortDateString(), out response, out OtpFeePerTime, out balance, out currentbalance);
                    if (response >= 1)
                    {
                        return new
                        {
                            ResponseCode = 1,

                        };
                    }
                    else
                    {
                        return new
                        {
                            ResponseCode = -99,
                            Message = ErrorMsg.OtpBusy
                        };
                    }

                }
                else
                {
                    balance = 0;
                    currentbalance = 0;
                    OtpFeePerTime = 0;

                    SMSDAO.Instance.UpdateStatus(responseCurrentID, -1, Convert.ToInt32(res.code), DateTime.Now.ToShortDateString(), out response, out OtpFeePerTime, out balance, out currentbalance);

                    //Description = "Hoàn " + OtpFeePerTime + " Bit vào tài khoản vì OTP gửi lỗi";
                    //  HistoryDAO.Instance.GameInsert(0, (int)OtpFeePerTime, 0, 0, 2, accountId, responseCurrentID, currentbalance, balance, 0, 0, IPAddressHelper.GetClientIP(), Description, out outResponse);
                    return new
                    {
                        ResponseCode = -99,
                        Message = ErrorMsg.OtpBusy
                    };

                }

            }
            
        }
        //protected dynamic GenerateOtp(long accountId, string phone, string type)
        //{
        //    var otp = SMSRequest.GenrateOTP();

        //    //trừ tiền mã otp
        //    long responseCurrentID = -99;
        //    long balance = 0;
        //    long currentbalance = 0;
        //    int OtpFeePerTime = 0;
        //    SMSDAO.Instance.OTPInit(accountId, type, otp, phone.PhoneFormat(), ServiceID, out balance, out currentbalance, out responseCurrentID, out OtpFeePerTime);

        //    if (responseCurrentID == -2)
        //    {
        //        return new
        //        {
        //            ResponseCode = -99,
        //            Message = ErrorMsg.OTPBitNotEngough
        //        };
        //    }
        //    else if (responseCurrentID <= 0 && responseCurrentID != -2)
        //    {

        //        return new
        //        {
        //            ResponseCode = -99,
        //            Message = ErrorMsg.OtpBusy
        //        };
        //    }

        //    var strOtpFormat = ConfigurationManager.AppSettings["OTP_MSG"].ToString();
        //    var sms = String.Format(strOtpFormat, otp);
        //    //  var sendResult = test.sendSms(username, pass, brand, sms, newPhone, 1);

        //    var res = OtpSend.Send(phone, sms);


        //    int response = 0;
        //    if (res.code == OtpSuccess.SUCESS)
        //    {
        //        balance = 0;
        //        currentbalance = 0;
        //        OtpFeePerTime = 0;

        //        SMSDAO.Instance.UpdateStatus(responseCurrentID, 1, 1, DateTime.Now.ToShortDateString(), out response, out OtpFeePerTime, out balance, out currentbalance);
        //        if (response >= 1)
        //        {
        //            return new
        //            {
        //                ResponseCode = 1,

        //            };
        //        }
        //        else
        //        {
        //            return new
        //            {
        //                ResponseCode = -99,
        //                Message = ErrorMsg.OtpBusy
        //            };
        //        }

        //    }
        //    else
        //    {
        //        balance = 0;
        //        currentbalance = 0;
        //        OtpFeePerTime = 0;

        //        SMSDAO.Instance.UpdateStatus(responseCurrentID, -1, Convert.ToInt32(res.code), DateTime.Now.ToShortDateString(), out response, out OtpFeePerTime, out balance, out currentbalance);

        //        //Description = "Hoàn " + OtpFeePerTime + " Bit vào tài khoản vì OTP gửi lỗi";
        //        //  HistoryDAO.Instance.GameInsert(0, (int)OtpFeePerTime, 0, 0, 2, accountId, responseCurrentID, currentbalance, balance, 0, 0, IPAddressHelper.GetClientIP(), Description, out outResponse);
        //        return new
        //        {
        //            ResponseCode = -99,
        //            Message = ErrorMsg.OtpBusy
        //        };

        //    }
        //}
    }
}
