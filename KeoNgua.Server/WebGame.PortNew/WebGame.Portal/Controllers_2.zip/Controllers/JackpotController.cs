﻿using System;
using System.Collections.Generic;
using System.Web.Http;
using MsWebGame.Portal.Database.DTO;
using MsWebGame.Portal.Database.DAO;

using MsWebGame.Portal.Handlers;
using System.Linq;
using TraditionGame.Utilities;

namespace MsWebGame.Portal.Controllers
{
    [RoutePrefix("api/Jackpot")]
    public class JackpotController : BaseApiController
    {
        /// <summary>
        /// jackport cho từng icon lớn trong game
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("GetJackpotInfo")]
        [AllowAnonymous]
        public dynamic GetJackpotInfo()
        {
            try
            {
                //handler cache data
                var lstRs = CachingHandler.GetListCache<JackpotInfo>("JackpotAllCa",ServiceID);
                if (lstRs != null)
                    return new { ResponseCode = 1, GameList = lstRs };

                lstRs = JackpotInfoDAO.Instance.GetGameJackPot();
                if (lstRs == null)
                    lstRs = new List<JackpotInfo>();

                CachingHandler.AddListCache<JackpotInfo>("JackpotAllCa", ServiceID, lstRs, 5);
                return new { ResponseCode = 1, GameList = lstRs };
            }
            catch
            {
                return new
                {
                    ResponseCode = 1,
                    list = new List<JackpotInfo>()
                };
            }
        }
        /// <summary>
        /// user jackport
        /// </summary>
        /// <returns></returns>
        [HttpOptions, HttpGet]
        [Route("GetUserJackpotInfo")]
        [AllowAnonymous]
        public dynamic GetUserJackpotInfo()
        {
            try
            {
                var lstRs = CachingHandler.GetListCache<UserJackPotInfo>("UserJackPotInfoCa",ServiceID);
                if (lstRs != null)
                {
                    return new
                    {
                        ResponseCode = 1,
                        list = lstRs,
                    };
                }

                var list = JackpotInfoDAO.Instance.GetUserJackportInfo();
                if (list == null)
                    list = new List<UserJackPotInfo>();
                CachingHandler.AddListCache<UserJackPotInfo>("UserJackPotInfoCa",ServiceID, list, 600);
                return new
                {
                    ResponseCode = 1,
                    list = list,
                };
            }
            catch (Exception ex)
            {
                return new
                {
                    ResponseCode = 1,
                    list = new List<UserJackPotInfo>()
                };
            }
        }

        [HttpGet]
        [Route("GetGameJackpotInfo")]
        [AllowAnonymous]
        public List<EventXJackpot> GetGameJackpotInfo()
        {
            try
            {
                var lstRs = CachingHandler.GetListCache<EventXJackpot>("EventXJackpotCa",ServiceID);
                if (lstRs != null&& lstRs.Any())
                    return lstRs;

                lstRs = JackpotInfoDAO.Instance.GetEventXJackpot();
                if (lstRs == null)
                    lstRs = new List<EventXJackpot>();

                CachingHandler.AddListCache<EventXJackpot>("EventXJackpotCa",ServiceID, lstRs, 30);
                return lstRs;
            }
            catch (Exception ex)
            {
                NLogManager.PublishException(ex);
                return null;
            }
        }

        [HttpPost]
        [ActionName("GunEffectJackpot")]
        public bool GunEffectJackpot([FromBody] EffectJackpot input)
        {
            try
            {
                NLogManager.LogMessage(string.Format("EffectJackpot-NickName:{0}| JackpotValue:{1}| BetValue:{2}| GameName:{3}",
                   input.NickName, input.JackpotValue, input.BetValue, input.GameName));
                if (string.IsNullOrEmpty(input.NickName) || input.JackpotValue < 1 || input.BetValue < 1 || string.IsNullOrEmpty(input.GameName)||input.ServiceID<=0)
                    return false;
                
                PortalHandler.Instance.GunEffectJackpot(input);
                return true;
            }
            catch (Exception ex)
            {
                NLogManager.PublishException(ex);
                return false;
            }
        }
    }
}
