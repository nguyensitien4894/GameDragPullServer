﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http;

using TraditionGame.Utilities.Messages;
using TraditionGame.Utilities.Session;
using TraditionGame.Utilities.Utils;
using MsWebGame.Portal.Database.DAO;
using MsWebGame.Portal.Database.DTO;
using MsWebGame.Portal.Handlers;
using TraditionGame.Utilities;

namespace MsWebGame.Portal.Controllers
{
    [RoutePrefix("api/Agency")]
    public class AgencyController : BaseApiController
    {
        [ActionName("GetList")]
        [HttpGet]
        //[Authorize]
        public dynamic GetList()
        {
            try
            {
                //handler cache data
                var lstRs = CachingHandler.GetListCache<Agency>("AgencyListCa",ServiceID);
                if (lstRs != null&&lstRs.Any())
                {
                    return new
                    {
                        ResponseCode = 1,
                        List = lstRs
                    };
                }

                int TotalRecord = 0;
                lstRs = AgencyDAO.Instance.GetList(null, null, null, 1,-1,1,ServiceID, 1, 50, out TotalRecord);
                if(lstRs == null)
                    lstRs = new List<Agency>();

                foreach (var item in lstRs)
                {
                    item.PhoneNo = string.IsNullOrEmpty(item.PhoneDisplay) ? string.Empty : item.PhoneDisplay.Replace(",", Environment.NewLine);
                };

                CachingHandler.AddListCache<Agency>("AgencyListCa", ServiceID, lstRs,600);
                return new
                {
                    ResponseCode = 1,
                    List = lstRs
                };
            }
            catch (Exception ex)
            {
                NLogManager.PublishException(ex);
                return new
                {
                    ResponseCode = -99,
                    Message = ErrorMsg.InProccessException
                };
            }
        }
    }
}